/*
 * GCC compatibility wrapper for the MSVC-generated MIDL client stub.
 *
 * windefend_c.c forward-declares its private format tables as "extern const"
 * and later defines them as "static const".  MSVC accepts that as warning
 * C4211, while GCC rejects the linkage mismatch.  All remaining extern tokens
 * in the generated client are those private table declarations, so this
 * wrapper gives them internal linkage without modifying the generated file.
 */
#include <string.h>
#include "../windefend_h.h"
#include <ndr64types.h>

#define extern static
#include "../windefend_c.c"
#undef extern
