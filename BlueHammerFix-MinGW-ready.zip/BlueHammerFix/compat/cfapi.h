/*
 * Minimal Cloud Files API declarations used by BlueHammer.
 *
 * MinGW-w64 does not currently ship cfapi.h or a CldApi import library.  The
 * declarations and x64 layout checks below cover only the API surface used by
 * FunnyApp.cpp.  They match the public Windows SDK ABI for Windows 10 RS5.
 */
#pragma once

#include <windows.h>

#ifndef _WIN64
#error BlueHammer requires a 64-bit Windows target
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct CF_CONNECTION_KEY__ {
    LONGLONG Internal;
} CF_CONNECTION_KEY, *PCF_CONNECTION_KEY;

typedef LARGE_INTEGER CF_TRANSFER_KEY;
typedef LARGE_INTEGER CF_REQUEST_KEY;

/* The application only forwards correlation-vector pointers to CldApi. */
typedef void CORRELATION_VECTOR;
typedef CORRELATION_VECTOR *PCORRELATION_VECTOR;

typedef struct CF_FS_METADATA {
    FILE_BASIC_INFO BasicInfo;
    LARGE_INTEGER FileSize;
} CF_FS_METADATA;

typedef enum CF_PLACEHOLDER_CREATE_FLAGS {
    CF_PLACEHOLDER_CREATE_FLAG_NONE = 0x00000000,
    CF_PLACEHOLDER_CREATE_FLAG_SUPERSEDE = 0x00000004
} CF_PLACEHOLDER_CREATE_FLAGS;

typedef struct CF_PLACEHOLDER_CREATE_INFO {
    LPCWSTR RelativeFileName;
    CF_FS_METADATA FsMetadata;
    LPCVOID FileIdentity;
    DWORD FileIdentityLength;
    CF_PLACEHOLDER_CREATE_FLAGS Flags;
    HRESULT Result;
    USN CreateUsn;
} CF_PLACEHOLDER_CREATE_INFO;

typedef struct CF_PROCESS_INFO {
    DWORD StructSize;
    DWORD ProcessId;
    PCWSTR ImagePath;
    PCWSTR PackageName;
    PCWSTR ApplicationId;
    PCWSTR CommandLine;
    DWORD SessionId;
} CF_PROCESS_INFO;

typedef enum CF_REGISTER_FLAGS {
    CF_REGISTER_FLAG_NONE = 0x00000000
} CF_REGISTER_FLAGS;

typedef enum CF_HYDRATION_POLICY_PRIMARY {
    CF_HYDRATION_POLICY_PARTIAL = 0
} CF_HYDRATION_POLICY_PRIMARY;

typedef enum CF_HYDRATION_POLICY_MODIFIER {
    CF_HYDRATION_POLICY_MODIFIER_NONE = 0x0000,
    CF_HYDRATION_POLICY_MODIFIER_VALIDATION_REQUIRED = 0x0001
} CF_HYDRATION_POLICY_MODIFIER;

typedef struct CF_HYDRATION_POLICY {
    USHORT Primary;
    USHORT Modifier;
} CF_HYDRATION_POLICY;

typedef struct CF_POPULATION_POLICY {
    USHORT Primary;
    USHORT Modifier;
} CF_POPULATION_POLICY;

typedef enum CF_PLACEHOLDER_MANAGEMENT_POLICY {
    CF_PLACEHOLDER_MANAGEMENT_POLICY_DEFAULT = 0x00000000
} CF_PLACEHOLDER_MANAGEMENT_POLICY;

typedef enum CF_INSYNC_POLICY {
    CF_INSYNC_POLICY_NONE = 0x00000000
} CF_INSYNC_POLICY;

typedef enum CF_HARDLINK_POLICY {
    CF_HARDLINK_POLICY_NONE = 0x00000000,
    CF_HARDLINK_POLICY_ALLOWED = 0x00000001
} CF_HARDLINK_POLICY;

typedef struct CF_SYNC_POLICIES {
    ULONG StructSize;
    CF_HYDRATION_POLICY Hydration;
    CF_POPULATION_POLICY Population;
    CF_INSYNC_POLICY InSync;
    CF_HARDLINK_POLICY HardLink;
    CF_PLACEHOLDER_MANAGEMENT_POLICY PlaceholderManagement;
} CF_SYNC_POLICIES;

typedef struct CF_SYNC_REGISTRATION {
    ULONG StructSize;
    LPCWSTR ProviderName;
    LPCWSTR ProviderVersion;
    LPCVOID SyncRootIdentity;
    DWORD SyncRootIdentityLength;
    LPCVOID FileIdentity;
    DWORD FileIdentityLength;
    GUID ProviderId;
} CF_SYNC_REGISTRATION;

typedef struct CF_CALLBACK_INFO {
    DWORD StructSize;
    CF_CONNECTION_KEY ConnectionKey;
    LPVOID CallbackContext;
    PCWSTR VolumeGuidName;
    PCWSTR VolumeDosName;
    DWORD VolumeSerialNumber;
    LARGE_INTEGER SyncRootFileId;
    LPCVOID SyncRootIdentity;
    DWORD SyncRootIdentityLength;
    LARGE_INTEGER FileId;
    LARGE_INTEGER FileSize;
    LPCVOID FileIdentity;
    DWORD FileIdentityLength;
    PCWSTR NormalizedPath;
    CF_TRANSFER_KEY TransferKey;
    UCHAR PriorityHint;
    PCORRELATION_VECTOR CorrelationVector;
    CF_PROCESS_INFO *ProcessInfo;
    CF_REQUEST_KEY RequestKey;
} CF_CALLBACK_INFO;

typedef struct CF_CALLBACK_PARAMETERS CF_CALLBACK_PARAMETERS;

typedef VOID (CALLBACK *CF_CALLBACK)(
    const CF_CALLBACK_INFO *CallbackInfo,
    const CF_CALLBACK_PARAMETERS *CallbackParameters
);

typedef enum CF_CALLBACK_TYPE {
    CF_CALLBACK_TYPE_FETCH_DATA = 0,
    CF_CALLBACK_TYPE_VALIDATE_DATA = 1,
    CF_CALLBACK_TYPE_CANCEL_FETCH_DATA = 2,
    CF_CALLBACK_TYPE_FETCH_PLACEHOLDERS = 3,
    CF_CALLBACK_TYPE_NONE = 0xffffffff
} CF_CALLBACK_TYPE;

typedef struct CF_CALLBACK_REGISTRATION {
    CF_CALLBACK_TYPE Type;
    CF_CALLBACK Callback;
} CF_CALLBACK_REGISTRATION;

typedef enum CF_CONNECT_FLAGS {
    CF_CONNECT_FLAG_NONE = 0x00000000,
    CF_CONNECT_FLAG_REQUIRE_PROCESS_INFO = 0x00000002,
    CF_CONNECT_FLAG_REQUIRE_FULL_FILE_PATH = 0x00000004
} CF_CONNECT_FLAGS;

typedef enum CF_OPERATION_TYPE {
    CF_OPERATION_TYPE_TRANSFER_DATA = 0,
    CF_OPERATION_TYPE_RETRIEVE_DATA = 1,
    CF_OPERATION_TYPE_ACK_DATA = 2,
    CF_OPERATION_TYPE_RESTART_HYDRATION = 3,
    CF_OPERATION_TYPE_TRANSFER_PLACEHOLDERS = 4
} CF_OPERATION_TYPE;

typedef struct CF_SYNC_STATUS CF_SYNC_STATUS;

typedef struct CF_OPERATION_INFO {
    ULONG StructSize;
    CF_OPERATION_TYPE Type;
    CF_CONNECTION_KEY ConnectionKey;
    CF_TRANSFER_KEY TransferKey;
    const CORRELATION_VECTOR *CorrelationVector;
    const CF_SYNC_STATUS *SyncStatus;
    CF_REQUEST_KEY RequestKey;
} CF_OPERATION_INFO;

typedef enum CF_OPERATION_TRANSFER_PLACEHOLDERS_FLAGS {
    CF_OPERATION_TRANSFER_PLACEHOLDERS_FLAG_NONE = 0x00000000
} CF_OPERATION_TRANSFER_PLACEHOLDERS_FLAGS;

typedef struct CF_OPERATION_PARAMETERS {
    ULONG ParamSize;
    union {
        struct {
            CF_OPERATION_TRANSFER_PLACEHOLDERS_FLAGS Flags;
            NTSTATUS CompletionStatus;
            LARGE_INTEGER PlaceholderTotalCount;
            CF_PLACEHOLDER_CREATE_INFO *PlaceholderArray;
            DWORD PlaceholderCount;
            DWORD EntriesProcessed;
        } TransferPlaceholders;
        BYTE Reserved[40];
    };
} CF_OPERATION_PARAMETERS;

HRESULT WINAPI CfRegisterSyncRoot(
    LPCWSTR SyncRootPath,
    const CF_SYNC_REGISTRATION *Registration,
    const CF_SYNC_POLICIES *Policies,
    CF_REGISTER_FLAGS RegisterFlags
);

HRESULT WINAPI CfUnregisterSyncRoot(LPCWSTR SyncRootPath);

HRESULT WINAPI CfConnectSyncRoot(
    LPCWSTR SyncRootPath,
    const CF_CALLBACK_REGISTRATION *CallbackTable,
    LPCVOID CallbackContext,
    CF_CONNECT_FLAGS ConnectFlags,
    CF_CONNECTION_KEY *ConnectionKey
);

HRESULT WINAPI CfDisconnectSyncRoot(CF_CONNECTION_KEY ConnectionKey);

HRESULT WINAPI CfExecute(
    const CF_OPERATION_INFO *OpInfo,
    CF_OPERATION_PARAMETERS *OpParams
);

#ifdef __cplusplus
} /* extern "C" */

inline CF_CONNECT_FLAGS operator|(CF_CONNECT_FLAGS lhs, CF_CONNECT_FLAGS rhs)
{
    return static_cast<CF_CONNECT_FLAGS>(
        static_cast<unsigned int>(lhs) | static_cast<unsigned int>(rhs)
    );
}

static_assert(sizeof(CF_CONNECTION_KEY) == 8, "Unexpected CF_CONNECTION_KEY ABI");
static_assert(sizeof(CF_FS_METADATA) == 48, "Unexpected CF_FS_METADATA ABI");
static_assert(sizeof(CF_PLACEHOLDER_CREATE_INFO) == 88, "Unexpected CF_PLACEHOLDER_CREATE_INFO ABI");
static_assert(sizeof(CF_PROCESS_INFO) == 48, "Unexpected CF_PROCESS_INFO ABI");
static_assert(sizeof(CF_SYNC_POLICIES) == 24, "Unexpected CF_SYNC_POLICIES ABI");
static_assert(sizeof(CF_SYNC_REGISTRATION) == 72, "Unexpected CF_SYNC_REGISTRATION ABI");
static_assert(sizeof(CF_CALLBACK_INFO) == 152, "Unexpected CF_CALLBACK_INFO ABI");
static_assert(sizeof(CF_CALLBACK_REGISTRATION) == 16, "Unexpected CF_CALLBACK_REGISTRATION ABI");
static_assert(sizeof(CF_OPERATION_INFO) == 48, "Unexpected CF_OPERATION_INFO ABI");
static_assert(sizeof(CF_OPERATION_PARAMETERS) == 48, "Unexpected CF_OPERATION_PARAMETERS ABI");
#endif
